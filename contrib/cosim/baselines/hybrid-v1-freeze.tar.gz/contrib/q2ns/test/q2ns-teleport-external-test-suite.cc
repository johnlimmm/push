// 실제 TeleportationApp의 비동기/ready/UDP 계약. NetSquid 물리 검증은 Python suite에서 수행한다.
#include "ns3/q2ns-teleportation-app.h"
#include "ns3/q2ns-qnode.h"
#include "ns3/q2ns-qstate-registry.h"
#include "ns3/q2ns-netcontroller.h"
#include "ns3/q2ns-qchannel.h"
#include "ns3/q2ns-qstate-ket.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/test.h"
#include <stdexcept>
using namespace ns3;
using namespace q2ns;
namespace {
Ipv4Address Connect(Ptr<Node> a,Ptr<Node> b) {
  InternetStackHelper internet;internet.SetIpv6StackInstall(false);internet.Install(NodeContainer(a,b));
  PointToPointHelper link;link.SetDeviceAttribute("DataRate",StringValue("100Mbps"));
  link.SetChannelAttribute("Delay",TimeValue(NanoSeconds(10000)));
  Ipv4AddressHelper addr;addr.SetBase("10.79.0.0","255.255.255.0");
  return addr.Assign(link.Install(NodeContainer(a,b))).GetAddress(1);
}
void Setup(Ptr<TeleportationApp> a,Ptr<TeleportationApp> b,Ptr<Node> na,Ptr<Node> nb,Ipv4Address dst) {
  na->AddApplication(a);nb->AddApplication(b);
  for (auto app:{a,b}) {
    app->SetAttribute("Role",StringValue(app==a?"source":"sink"));
    app->SetAttribute("SessionId",UintegerValue(7));
    app->SetAttribute("Peer",Ipv4AddressValue(dst));
    app->SetAttribute("CtrlPort",UintegerValue(7000));
    app->SetStartTime(NanoSeconds(0));
  }
}
class ContractCase:public TestCase {
  int m_mode;
public:
  ContractCase(int mode):TestCase(mode==0?"teleport external: actual UDP, duplicates, invalid bits, readiness first":
    mode==1?"teleport external: control arrives before Bob resource ready":
    mode==2?"teleport external: stop rejects late BSM completion":
    mode==3?"teleport external: stop rejects late correction completion":
            "teleport external: stop ignores late result packet"),m_mode(mode){}
  void DoRun() override {
    QStateRegistry registry;
    auto na=CreateObject<QNode>(registry),nb=CreateObject<QNode>(registry);
    auto dst=Connect(na,nb);
    auto a=CreateObject<TeleportationApp>(),b=CreateObject<TeleportationApp>();
    Setup(a,b,na,nb,dst);
    int requests=0,corrections=0,applied=0,received=0;
    a->ConfigureExternal({201,202,203},[&](uint64_t sid,const TeleportationApp::ExternalResources& r) {
      ++requests;NS_TEST_ASSERT_MSG_EQ(sid,7,"session");NS_TEST_ASSERT_MSG_EQ(r.input,201,"input handle");
      NS_TEST_ASSERT_MSG_EQ(Simulator::Now().GetNanoSeconds(),2000,"request waits for source resources");
    },{});
    b->ConfigureExternal({201,202,203},{},[&](uint64_t sid,uint64_t target,uint8_t m1,uint8_t m2) {
      ++corrections;
      NS_TEST_ASSERT_MSG_EQ(target,203,"target handle");
      NS_TEST_ASSERT_MSG_EQ(m1,1,"Z bit");NS_TEST_ASSERT_MSG_EQ(m2,1,"X bit");
      NS_TEST_ASSERT_MSG_EQ(Simulator::Now().GetNanoSeconds(),m_mode==1?25000:17560,"ready and actual packet RX");
      if(m_mode==3)b->StopApplication();
      Simulator::Schedule(NanoSeconds(7000),[&,sid] {
        NS_TEST_ASSERT_MSG_EQ(b->CompleteExternalCorrection(sid),m_mode!=3,"async completion guard");
        NS_TEST_ASSERT_MSG_EQ(b->CompleteExternalCorrection(sid),false,"duplicate completion");
      });
    });
    a->SetExternalPacketObservers([&](uint64_t,uint8_t,uint8_t,Ptr<Packet> p) {
      NS_TEST_ASSERT_MSG_EQ(p->GetSize(),2,"original native payload retained");
      auto socket=Socket::CreateSocket(na,UdpSocketFactory::GetTypeId());
      Simulator::Schedule(NanoSeconds(10000),[socket,p,dst] {
        socket->SendTo(p->Copy(),0,InetSocketAddress(dst,7000));socket->Close();
      });
    },{});
    b->SetExternalPacketObservers({},[&](uint64_t,uint8_t,uint8_t,Ptr<Packet>){++received;});
    b->m_traceSinkCorrection.ConnectWithoutContext(Callback<void,uint64_t,Time>([&](uint64_t,Time){++applied;}));
    if(m_mode!=1)NS_TEST_ASSERT_MSG_EQ(b->NotifyExternalResourcesReady(7),true,"early ready");
    Simulator::Schedule(NanoSeconds(1000),[&] {
      NS_TEST_ASSERT_MSG_EQ(a->CompleteExternalBsm(7,0,0),false,"unsolicited completion");
      NS_TEST_ASSERT_MSG_EQ(b->CompleteExternalCorrection(7),false,"premature correction");
      NS_TEST_ASSERT_MSG_EQ(a->RequestExternalBsm(99),false,"unknown session");
      NS_TEST_ASSERT_MSG_EQ(b->RequestExternalBsm(7),false,"wrong role");
      NS_TEST_ASSERT_MSG_EQ(a->RequestExternalBsm(7),true,"first request");
      NS_TEST_ASSERT_MSG_EQ(requests,0,"not ready");
      NS_TEST_ASSERT_MSG_EQ(a->RequestExternalBsm(7),false,"duplicate request");
    });
    Simulator::Schedule(NanoSeconds(2000),[&] {
      NS_TEST_ASSERT_MSG_EQ(a->NotifyExternalResourcesReady(99),false,"wrong ready session");
      NS_TEST_ASSERT_MSG_EQ(a->NotifyExternalResourcesReady(7),true,"ready");
      NS_TEST_ASSERT_MSG_EQ(a->NotifyExternalResourcesReady(7),false,"duplicate ready");
    });
    if(m_mode==2)Simulator::Schedule(NanoSeconds(4000),[a]{a->StopApplication();});
    if(m_mode==4)Simulator::Schedule(NanoSeconds(4000),[b]{b->StopApplication();});
    Simulator::Schedule(NanoSeconds(5000),[&] {
      NS_TEST_ASSERT_MSG_EQ(a->CompleteExternalBsm(7,2,0),false,"invalid measurement bit");
      NS_TEST_ASSERT_MSG_EQ(a->CompleteExternalBsm(7,1,1),m_mode!=2,"BSM completion");
      NS_TEST_ASSERT_MSG_EQ(a->CompleteExternalBsm(7,1,1),false,"duplicate BSM completion");
    });
    if(m_mode==1)Simulator::Schedule(NanoSeconds(25000),[&] {
      NS_TEST_ASSERT_MSG_EQ(received,1,"bits arrived before ready");
      NS_TEST_ASSERT_MSG_EQ(corrections,0,"correction still waits");
      NS_TEST_ASSERT_MSG_EQ(b->NotifyExternalResourcesReady(7),true,"late resource ready");
    });
    Simulator::Stop(MilliSeconds(1));Simulator::Run();
    NS_TEST_ASSERT_MSG_EQ(requests,1,"BSM once");
    NS_TEST_ASSERT_MSG_EQ(corrections,(m_mode==2||m_mode==4)?0:1,"correction once");
    NS_TEST_ASSERT_MSG_EQ(applied,(m_mode>=2)?0:1,"completion once");
    NS_TEST_ASSERT_MSG_EQ(received,(m_mode==2||m_mode==4)?0:1,"duplicate ignored");
    NS_TEST_ASSERT_MSG_EQ(registry.GetStatesSortedById().size(),0,"no native quantum states");
    NS_TEST_ASSERT_MSG_EQ(na->GetLocalQubits().size()+nb->GetLocalQubits().size(),0,"no native qubits");
    Simulator::Destroy();
  }
};
class ConfigCase:public TestCase {
public:
  ConfigCase():TestCase("teleport external: invalid configuration rejected"){}
  void DoRun() override {
    for(int mode=0;mode<5;++mode) {
      auto a=CreateObject<TeleportationApp>();a->SetAttribute("SessionId",UintegerValue(7));TeleportationApp::ExternalResources ids{201,202,203};
      if(mode==0)ids.input=0;
      if(mode==1)ids.epr=201;
      if(mode==2)a->SetAttribute("ClassicalProtocol",StringValue("tcp"));
      if(mode==3)a->SetAttribute("Role",StringValue("bad"));
      bool caught=false;
      try {a->ConfigureExternal(ids,mode==4?TeleportationApp::ExternalBsmRequest{}:
        [](uint64_t,const TeleportationApp::ExternalResources&){},{});}catch(const std::exception&){caught=true;}
      NS_TEST_ASSERT_MSG_EQ(caught,true,"unsupported external config");
    }
    Simulator::Destroy();
  }
};
class NativeCase:public TestCase {
public:
  NativeCase():TestCase("teleport native: built-in preparation, quantum send, BSM and correction retained"){}
  void DoRun() override {
    NetController net;
    auto na=net.CreateNode(),nb=net.CreateNode();
    auto dst=Connect(na,nb);
    net.InstallQuantumLink(na,nb)->SetAttribute("Delay",TimeValue(NanoSeconds(10)));
    auto a=CreateObject<TeleportationApp>(),b=CreateObject<TeleportationApp>();
    Setup(a,b,na,nb,dst);
    a->SetAttribute("PeerQNode",PointerValue(nb));
    a->SetTeleportState(std::make_shared<QStateKet>(1));
    int bsm=0,corrected=0;
    a->m_traceSourceBellDone.ConnectWithoutContext(Callback<void,uint64_t,Time>([&](uint64_t,Time){++bsm;}));
    b->m_traceSinkCorrection.ConnectWithoutContext(Callback<void,uint64_t,Time>([&](uint64_t,Time){++corrected;}));
    Simulator::Stop(MilliSeconds(1));Simulator::Run();
    NS_TEST_ASSERT_MSG_EQ(bsm,1,"native BSM");
    NS_TEST_ASSERT_MSG_EQ(corrected,1,"native correction");
    NS_TEST_ASSERT_MSG_EQ(net.GetRegistry().GetStatesSortedById().empty(),false,"native state retained");
    NS_TEST_ASSERT_MSG_EQ(nb->GetLocalQubits().size(),1,"native receiver qubit");
    Simulator::Destroy();
  }
};
class ExternalSuite:public TestSuite {
public:
  ExternalSuite():TestSuite("q2ns-teleport-external",Type::UNIT) {
    for(int mode=0;mode<5;++mode)AddTestCase(new ContractCase(mode),TestCase::Duration::QUICK);
    AddTestCase(new ConfigCase,TestCase::Duration::QUICK);
    AddTestCase(new NativeCase,TestCase::Duration::QUICK);
  }
} g_externalSuite;
}
