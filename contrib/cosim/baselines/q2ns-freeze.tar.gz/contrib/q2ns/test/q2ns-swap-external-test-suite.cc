// SwapApp의 비동기 경계와 기존 내장 quantum 경로를 함께 검사한다.
#include "ns3/q2ns-swap-app.h"
#include "ns3/q2ns-netcontroller.h"
#include "ns3/q2ns-qnode.h"
#include "ns3/q2ns-qchannel.h"
#include "ns3/q2ns-qstate-registry.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/test.h"

#include <stdexcept>

using namespace ns3;
using namespace q2ns;

namespace {

template<class F> bool Throws(F call) {
  try { call(); } catch (const std::exception&) { return true; }
  return false;
}

Ipv4Address Classical(Ptr<Node> r, Ptr<Node> b) {
  PointToPointHelper link;
  link.SetDeviceAttribute("DataRate", StringValue("100Mbps"));
  link.SetChannelAttribute("Delay", TimeValue(NanoSeconds(10000)));
  auto devices=link.Install(NodeContainer(r,b));
  Ipv4AddressHelper address;
  address.SetBase("10.78.0.0", "255.255.255.0");
  return address.Assign(devices).GetAddress(1);
}

class ExternalContractCase : public TestCase {
public:
  ExternalContractCase() : TestCase("SwapApp external: actual UDP, async completion, duplicate guards, sole ownership") {}
  void DoRun() override {
    QStateRegistry registry;
    auto r=CreateObject<QNode>(registry), b=CreateObject<QNode>(registry);
    InternetStackHelper internet;
    internet.SetIpv6StackInstall(false);
    NodeContainer nodes; nodes.Add(r); nodes.Add(b);
    internet.Install(nodes);
    auto dst=Classical(r,b);
    auto appR=CreateObject<SwapApp>(), appB=CreateObject<SwapApp>();
    r->AddApplication(appR); b->AddApplication(appB);
    appR->SetPayloadBytes(80);
    appR->SetStartTime(NanoSeconds(0)); appB->SetStartTime(NanoSeconds(0));
    int requests=0, sends=0, corrections=0, applied=0, received=0;
    appR->SetExternalQuantumCallbacks([&](uint64_t sid,const SwapApp::ExternalResources& ids) {
      ++requests;
      NS_TEST_ASSERT_MSG_EQ(sid, 7, "session routing");
      NS_TEST_ASSERT_MSG_EQ(ids.pairPrev, 101, "logical EPR mapping");
      NS_TEST_ASSERT_MSG_EQ(Simulator::Now().GetNanoSeconds(), 1000, "request time");
    }, {});
    appB->SetExternalQuantumCallbacks({}, [&](uint64_t sid,uint64_t pair,uint8_t m1,uint8_t m2) {
      ++corrections;
      NS_TEST_ASSERT_MSG_EQ(pair,103,"correction target");
      NS_TEST_ASSERT_MSG_EQ(m1,1,"wire Z bit"); NS_TEST_ASSERT_MSG_EQ(m2,0,"wire X bit");
      NS_TEST_ASSERT_MSG_EQ(Simulator::Now().GetNanoSeconds(),23800,"actual UDP arrival");
      Simulator::Schedule(NanoSeconds(7000), [&,sid] {
        NS_TEST_ASSERT_MSG_EQ(appB->CompleteExternalCorrection(sid),true,"first completion");
        NS_TEST_ASSERT_MSG_EQ(appB->CompleteExternalCorrection(sid),false,"duplicate completion");
      });
    });
    appR->SetExternalPacketObservers([&](uint64_t,uint8_t,uint8_t,Ptr<Packet> p) {
      ++sends;
      NS_TEST_ASSERT_MSG_EQ(Simulator::Now().GetNanoSeconds(),5000,"no early result");
      // 동일 UDP 결과가 재수신되어도 XOR/보정을 두 번 하지 않는다.
      auto socket=Socket::CreateSocket(r,UdpSocketFactory::GetTypeId());
      Simulator::Schedule(NanoSeconds(10000), [socket,p,dst] {
        socket->SendTo(p->Copy(),0,InetSocketAddress(dst,9000));
        socket->Close();
      });
    }, {});
    appB->SetExternalPacketObservers({}, [&](uint64_t,uint8_t,uint8_t,Ptr<Packet>){ ++received; });
    appB->m_traceCorrectionApplied.ConnectWithoutContext(Callback<void,uint64_t,Time>(
      [&](uint64_t,Time at) {
        ++applied;
        NS_TEST_ASSERT_MSG_EQ(at.GetNanoSeconds(),30800,"completion only after external ack");
      }));
    SwapApp::SessionConfig cfg;
    cfg.sid=7; cfg.ctrlPort=9000; cfg.nextEndAddr=dst;
    appR->AddExternalSession(cfg,{101,102,103});
    NS_TEST_ASSERT_MSG_EQ(Throws([&]{appR->AddExternalSession(cfg,{101,102,103});}),true,"duplicate session");
    cfg.role=SwapApp::Role::Next; cfg.applyCorrections=true;
    appB->AddExternalSession(cfg,{101,102,103});
    Simulator::Schedule(NanoSeconds(100), [&] {
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{appR->CompleteExternalBsm(7,1,0);}),true,"unsolicited BSM completion");
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{appB->CompleteExternalCorrection(7);}),true,"unsolicited correction completion");
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{appB->RequestExternalBsm(7);}),true,"wrong role");
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{appR->RequestExternalBsm(99);}),true,"unknown session");
    });
    Simulator::Schedule(NanoSeconds(1000), [&] {
      NS_TEST_ASSERT_MSG_EQ(appR->RequestExternalBsm(7),true,"first request");
      NS_TEST_ASSERT_MSG_EQ(appR->RequestExternalBsm(7),false,"duplicate pending request");
    });
    Simulator::Schedule(NanoSeconds(5000), [&] {
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{appR->CompleteExternalBsm(7,2,0);}),true,"invalid bit");
      NS_TEST_ASSERT_MSG_EQ(appR->CompleteExternalBsm(7,1,0),true,"valid BSM completion");
      NS_TEST_ASSERT_MSG_EQ(appR->CompleteExternalBsm(7,1,0),false,"duplicate BSM completion");
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{appR->CompleteExternalBsm(7,0,0);}),true,"conflicting completion");
      NS_TEST_ASSERT_MSG_EQ(appR->RequestExternalBsm(7),false,"consumed session");
    });
    Simulator::Stop(MilliSeconds(1)); Simulator::Run();
    NS_TEST_ASSERT_MSG_EQ(requests,1,"BSM exactly once"); NS_TEST_ASSERT_MSG_EQ(sends,1,"send exactly once");
    NS_TEST_ASSERT_MSG_EQ(received,1,"duplicate result ignored");
    NS_TEST_ASSERT_MSG_EQ(corrections,1,"correction exactly once"); NS_TEST_ASSERT_MSG_EQ(applied,1,"ack exactly once");
    NS_TEST_ASSERT_MSG_EQ(registry.GetStatesSortedById().size(),0,"no duplicate Q2NS quantum states");
    NS_TEST_ASSERT_MSG_EQ(r->GetLocalQubits().size()+b->GetLocalQubits().size(),0,"no native qubits");
    appR->StopApplication();
    NS_TEST_ASSERT_MSG_EQ(Throws([&]{appR->RequestExternalBsm(7);}),true,"stopped application");
    Simulator::Destroy();
  }
};

class StoppedEndpointCase : public TestCase {
public:
  StoppedEndpointCase() : TestCase("SwapApp external: late result after endpoint stop is ignored") {}
  void DoRun() override {
    QStateRegistry registry;
    auto r=CreateObject<QNode>(registry), b=CreateObject<QNode>(registry);
    NodeContainer nodes; nodes.Add(r); nodes.Add(b);
    InternetStackHelper internet; internet.SetIpv6StackInstall(false); internet.Install(nodes);
    auto dst=Classical(r,b);
    auto appR=CreateObject<SwapApp>(), appB=CreateObject<SwapApp>();
    r->AddApplication(appR); b->AddApplication(appB);
    int received=0, corrections=0;
    appR->SetExternalQuantumCallbacks([](uint64_t,const SwapApp::ExternalResources&){}, {});
    appB->SetExternalQuantumCallbacks({}, [&](uint64_t,uint64_t,uint8_t,uint8_t){++corrections;});
    appB->m_traceFrameResolved.ConnectWithoutContext(Callback<void,uint64_t,Time,uint8_t,uint8_t>(
      [&](uint64_t,Time,uint8_t,uint8_t){++received;}));
    SwapApp::SessionConfig cfg; cfg.sid=1; cfg.nextEndAddr=dst;
    appR->AddExternalSession(cfg,{101,102,103});
    cfg.role=SwapApp::Role::Next; cfg.applyCorrections=true;
    appB->AddExternalSession(cfg,{101,102,103});
    Simulator::Schedule(NanoSeconds(1000), [appR]{appR->RequestExternalBsm(1);});
    Simulator::Schedule(NanoSeconds(2000), [appB]{appB->StopApplication();});
    Simulator::Schedule(NanoSeconds(5000), [appR]{appR->CompleteExternalBsm(1,0,1);});
    Simulator::Stop(MilliSeconds(1)); Simulator::Run();
    NS_TEST_ASSERT_MSG_EQ(received,0,"stopped endpoint must not resolve a frame");
    NS_TEST_ASSERT_MSG_EQ(corrections,0,"stopped endpoint must not request correction");
    Simulator::Destroy();
  }
};

class ExternalConfigCase : public TestCase {
public:
  ExternalConfigCase() : TestCase("SwapApp external: unsupported configurations rejected") {}
  void DoRun() override {
    auto node=CreateObject<Node>();
    InternetStackHelper internet; internet.Install(node);
    auto app=CreateObject<SwapApp>(); node->AddApplication(app);
    app->SetExternalQuantumCallbacks([](uint64_t,const SwapApp::ExternalResources&){},{});
    SwapApp::SessionConfig cfg; cfg.sid=1; cfg.nextEndAddr=Ipv4Address("10.78.0.2");
    for (int defect=0;defect<8;++defect) {
      auto c=cfg;
      SwapApp::ExternalResources ids{101,102,103};
      switch (defect) {
      case 0: c.genNext=true; break;
      case 1: c.verifyFidelity=true; break;
      case 2: c.expectedMsgs=2; break;
      case 3: c.proto="tcp"; break;
      case 4: c.role=SwapApp::Role::Prev; break;
      case 5: ids.pairNext=101; break;
      case 6: ids.outputPair=0; break;
      case 7: c.nextEndAddr=Ipv4Address::GetAny(); break;
      }
      NS_TEST_ASSERT_MSG_EQ(Throws([&]{app->AddExternalSession(c,ids);}),true,"unsupported configuration");
    }
    app->SetUseIpv6(true);
    NS_TEST_ASSERT_MSG_EQ(Throws([&]{app->AddExternalSession(cfg,{101,102,103});}),true,"IPv6 scope");
    Simulator::Destroy();
  }
};

class NativeRegressionCase : public TestCase {
public:
  NativeRegressionCase() : TestCase("SwapApp native: built-in BSM and Pauli path still completes") {}
  void DoRun() override {
    NetController net;
    auto a=net.CreateNode(), r=net.CreateNode(), b=net.CreateNode();
    InternetStackHelper internet; internet.SetIpv6StackInstall(false);
    NodeContainer nodes; nodes.Add(a); nodes.Add(r); nodes.Add(b);
    internet.Install(nodes);
    auto dst=Classical(r,b);
    net.InstallQuantumLink(a,r)->SetAttribute("Delay",TimeValue(NanoSeconds(10)));
    net.InstallQuantumLink(r,b)->SetAttribute("Delay",TimeValue(NanoSeconds(10)));
    auto appA=CreateObject<SwapApp>(), appR=CreateObject<SwapApp>(), appB=CreateObject<SwapApp>();
    a->AddApplication(appA); r->AddApplication(appR); b->AddApplication(appB);
    int bsm=0, correction=0;
    appR->m_traceBSMDone.ConnectWithoutContext(Callback<void,uint64_t,Time,uint8_t,uint8_t>(
      [&](uint64_t,Time,uint8_t,uint8_t){++bsm;}));
    appB->m_traceCorrectionApplied.ConnectWithoutContext(Callback<void,uint64_t,Time>(
      [&](uint64_t,Time){++correction;}));
    SwapApp::SessionConfig cfg; cfg.sid=1; cfg.start=NanoSeconds(1000); cfg.ctrlPort=9000;
    cfg.role=SwapApp::Role::Prev; cfg.genNext=true; cfg.nextPeerId=r->GetId();
    appA->AddSession(cfg);
    cfg.role=SwapApp::Role::Repeater; cfg.nextPeerId=b->GetId(); cfg.nextEndAddr=dst;
    appR->AddSession(cfg);
    cfg.role=SwapApp::Role::Next; cfg.genNext=false; cfg.applyCorrections=true;
    appB->AddSession(cfg);
    Simulator::Stop(MilliSeconds(1)); Simulator::Run();
    NS_TEST_ASSERT_MSG_EQ(bsm,1,"native BSM"); NS_TEST_ASSERT_MSG_EQ(correction,1,"native correction");
    NS_TEST_ASSERT_MSG_EQ(net.GetRegistry().GetStatesSortedById().empty(),false,"native state ownership retained");
    Simulator::Destroy();
  }
};

class SwapExternalSuite : public TestSuite {
public:
  SwapExternalSuite() : TestSuite("q2ns-swap-external",Type::UNIT) {
    AddTestCase(new ExternalContractCase,TestCase::Duration::QUICK);
    AddTestCase(new StoppedEndpointCase,TestCase::Duration::QUICK);
    AddTestCase(new ExternalConfigCase,TestCase::Duration::QUICK);
    AddTestCase(new NativeRegressionCase,TestCase::Duration::QUICK);
  }
} g_swapExternalSuite;
} // namespace
